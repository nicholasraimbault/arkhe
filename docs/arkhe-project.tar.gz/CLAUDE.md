# CLAUDE.md — arkhe init system

## What is this project?

arkhe (ἀρχή — "origin", "first principle") is a Linux init system built on Pronoia Design principles. It is the first init system built entirely on post-2019 kernel APIs. It is a Rust project.

arkhe is NOT another systemd clone. It is NOT another minimal init. It is a new category: a pronoic init — structurally secure by default, effortless for users, and auditable by design.

## Design philosophy: Pronoia Design

Read `docs/PHILOSOPHY.md` for the full framework. The short version:

**Pronoia Design** is the discipline of building systems that are structurally on the user's side — where the architecture conspires for the user's benefit without requiring their awareness, configuration, or trust.

For arkhe specifically:
- Every service is sandboxed by default. There is no unsandboxed mode.
- The user drops a script in a directory and gets supervision + sandboxing + logging + dependency ordering for free.
- The entire codebase is under 10K lines. A single person can audit it in a day.
- Plain text everything. No binary formats. No custom protocols.
- The filesystem IS the IPC. No D-Bus. No message passing.

## Architecture overview

Read `docs/ARCHITECTURE.md` for full details. Summary:

```
PID 1 (200 lines, C or minimal Rust #![no_std])
  └── Supervisor (Rust, io_uring event loop)
        ├── Service spawner
        │     ├── clone3 (CLONE_PIDFD | CLONE_INTO_CGROUP | CLONE_NEWPID | CLONE_NEWNS)
        │     ├── close_range() — prevent fd leaks
        │     ├── New mount API (fsopen/fsmount/move_mount) — mount namespace
        │     ├── mount_setattr + MOUNT_ATTR_IDMAP — uid/gid mapping
        │     ├── Landlock ruleset — filesystem + network + IPC scoping
        │     ├── seccomp-bpf — syscall filter
        │     └── prctl — drop capabilities
        ├── Dependency resolver (inotify on /run/ready/)
        ├── Log router (io_uring splice, pipe → file)
        ├── Socket activator (io_uring multishot accept)
        ├── Resource monitor (PSI eventfd per service cgroup)
        └── Status reporter (plain text /run/arkhe/)
```

## Key technical decisions

### Language
- Supervisor and all tooling: Rust (stable, no nightly features)
- PID 1 stub: either C (200 lines) or Rust `#![no_std]` — whichever is simpler
- Zero `unsafe` blocks in the supervisor. All syscalls through `rustix` safe wrappers.
- `panic = "abort"` for PID 1. No unwinding. No allocation in PID 1.

### Kernel API surface (minimum kernel 6.12+)
- **pidfd**: `clone3` + `CLONE_PIDFD`, `waitid(P_PIDFD)`, pollable pidfds for process lifecycle
- **io_uring**: single ring for the entire supervisor event loop (process exits, inotify, signals, logs, sockets)
- **Landlock LSM**: default-deny filesystem + network + IPC scoping (ABI v6)
- **seccomp-bpf**: syscall whitelist per service
- **cgroup v2**: resource accounting, PSI monitoring, `CLONE_INTO_CGROUP` for atomic placement
- **inotify**: dependency resolution via `/run/ready/` file existence
- **signalfd**: signal handling in the event loop
- **Namespaces**: PID, mount, IPC, UTS, network — for process isolation
- **ID-mapped mounts**: `mount_setattr` + `MOUNT_ATTR_IDMAP` for per-service uid/gid mapping
- **New mount API**: `fsopen`/`fsmount`/`move_mount`/`open_tree` for mount namespace setup
- **close_range()**: prevent fd leaks into services
- **PSI**: Pressure Stall Information eventfd triggers per service cgroup

### Dependencies (target: <10 transitive crates)
- `rustix` — safe syscall wrappers (well-audited, Rust ecosystem team)
- `io-uring` — Rust io_uring bindings (tokio team)
- NO async runtime (no tokio, no async-std — hand-written io_uring loop)
- NO serde (no deserialization of untrusted formats)
- NO logging framework (services write to stdout, logger pipe handles it)

### What arkhe does NOT do
- No D-Bus
- No binary log format
- No DNS resolution
- No device management (separate process, like eudev)
- No login/seat management
- No timer scheduling in PID 1 (separate supervised service)
- No container management
- No home directory encryption

## Internal architecture: ECS pattern

arkhe uses an Entity-Component-System (ECS) pattern — NOT an ECS framework. No bevy_ecs, no hecs. Just parallel Vecs indexed by ServiceId. This is data-oriented design: organize around data transformations, not object hierarchies.

**Why ECS:**
- Not every service has every feature (sockets, dependencies, resource limits). Optional components handle this naturally.
- Each system (spawn, supervise, dependency resolution, logging) is an independent function operating on a subset of components. Independently testable.
- Adding features = adding a component + a system. No existing code changes. Keeps the codebase under 10K lines as capabilities grow.
- The architecture matches the on-disk format: each component corresponds to a file in `/etc/sv/<name>/`.

**Entity** = a service, identified by `ServiceId` (a `usize` index)

**Components** (per-service data, parallel arrays):
- `RunConfig` — run script path, finish script
- `Dependencies` — dependency name list
- `SandboxConfig` — Landlock rules, namespace flags, capabilities
- `ResourceLimits` — cgroup settings
- `ListenSockets` — socket activation config
- `LogConfig` — rotation settings
- `RuntimeState` — pid, pidfd, state enum, uptime, restart count
- `ReadinessState` — mode, timeout, satisfied
- `CgroupHandle` — cgroup fd, PSI eventfds

**Systems** (functions that iterate over entities with specific component combinations):
- `SpawnSystem` — starts services with satisfied dependencies
- `SupervisionSystem` — handles process exits, schedules restarts
- `DependencySystem` — updates dependency satisfaction on inotify events
- `LogSystem` — routes log data via io_uring splice
- `SocketSystem` — handles socket activation on accept events
- `PressureSystem` — monitors PSI eventfds, logs warnings
- `StatusSystem` — writes plain text status to /run/arkhe/

**World struct** holds all component storage + reverse lookup maps (pidfd→ServiceId, socket_fd→ServiceId, psi_fd→ServiceId).

**The io_uring event loop IS the ECS scheduler.** Each ring completion is dispatched to the appropriate system based on the user_data tag.

## File structure

```
arkhe/
├── CLAUDE.md                  # This file
├── Cargo.toml
├── docs/
│   ├── PHILOSOPHY.md          # Pronoia Design framework
│   ├── ARCHITECTURE.md        # Full technical architecture
│   ├── CVE-STRATEGY.md        # Security hardening strategy
│   ├── API-SURFACE.md         # Kernel API reference
│   ├── SANDBOX.md             # Sandbox system design
│   ├── SERVICE-FORMAT.md      # Service file format specification
│   └── CLI.md                 # CLI design and output formats
├── pid1/                      # PID 1 stub (C or no_std Rust)
│   └── main.c (or main.rs)
├── src/
│   ├── main.rs                # Startup, io_uring loop, system dispatch
│   ├── world.rs               # World struct, ServiceId, component storage
│   ├── components.rs          # Component type definitions
│   ├── systems/
│   │   ├── mod.rs             # System trait / dispatch
│   │   ├── spawn.rs           # SpawnSystem
│   │   ├── supervise.rs       # SupervisionSystem
│   │   ├── deps.rs            # DependencySystem
│   │   ├── log.rs             # LogSystem
│   │   ├── socket.rs          # SocketSystem
│   │   ├── pressure.rs        # PressureSystem
│   │   └── status.rs          # StatusSystem
│   ├── sandbox.rs             # Landlock + seccomp + namespace setup
│   ├── ring.rs                # io_uring wrapper
│   ├── cgroup.rs              # cgroup v2 operations
│   └── config.rs              # Parse /etc/sv/ into components
├── ark/                       # CLI binary (separate from supervisor)
│   ├── Cargo.toml
│   └── src/
│       ├── main.rs
│       └── cli.rs
└── tests/
    └── ...
```

## Build and test

```bash
cargo build --release
# PID 1 stub (if C):
cc -static -O2 -o pid1 pid1/main.c
```

Testing without being PID 1:
- Use Linux user namespaces + unshare for testing sandbox features
- Use a VM or container for full init testing
- Unit tests for config parsing, sandbox rule generation, cgroup paths
- Integration tests for service lifecycle (spawn → ready → stop → restart)

## Performance targets

| Metric | Target |
|---|---|
| Boot to ready (50 services) | <1 second |
| PID 1 memory | <1 MB |
| Total init stack memory | <4 MB |
| Per-service launch overhead | <500μs (including sandbox setup) |
| Sandbox setup cost | <200μs per service |
| Seccomp filter overhead | <50ns per syscall |

## Code quality rules

1. No `unsafe` in the supervisor. Period. If a syscall needs unsafe, it goes through rustix.
2. No panics in PID 1. PID 1 does not allocate.
3. Every public function has a doc comment.
4. Every error is handled explicitly. No `.unwrap()` in production code.
5. Plain text config parsing is done with string splitting. No parser combinators, no grammars.
6. The entire codebase stays under 10K lines. If it's growing past that, something is wrong architecturally.

## What to build first (priority order)

1. **PID 1 stub** — reap zombies, forward signals, exec supervisor
2. **World + Components** — define ServiceId, World struct, all component types
3. **Config parser** — read `/etc/sv/` directories, populate World with components
4. **io_uring event loop skeleton** — ring setup, signalfd, dispatch by user_data tag
5. **SpawnSystem** — clone3 with CLONE_PIDFD, basic namespace setup
6. **SupervisionSystem** — pidfd completion handling, restart with backoff
7. **DependencySystem** — inotify on /run/ready/, readiness protocol
8. **Sandbox module** — Landlock + seccomp + capabilities (called by SpawnSystem)
9. **LogSystem** — io_uring splice from service pipes to log files
10. **SocketSystem** — io_uring multishot accept, socket activation
11. **CgroupSystem** — resource limits, PSI monitoring
12. **StatusSystem** — write plain text to /run/arkhe/
13. **CLI** — `ark status`, `ark log`, `ark check`, `ark new`
14. **ID-mapped mounts** — per-service uid/gid mapping in SpawnSystem
15. **Reproducible build setup**
