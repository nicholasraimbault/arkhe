/*
 * arkhe PID 1 stub
 *
 * This is the simplest correct init process. It does exactly what the
 * kernel requires of PID 1 and nothing else:
 *   1. Reap zombie processes (waitpid loop)
 *   2. Forward signals to the supervisor
 *   3. Exec the supervisor as the first child
 *
 * No heap allocation. No config parsing. No IPC. No error recovery.
 * If this process exits, the kernel panics. Keep it simple.
 *
 * Target: <200 lines. Currently: ~120 lines.
 */

#define _GNU_SOURCE
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <sys/reboot.h>
#include <linux/reboot.h>

#define SUPERVISOR_PATH "/usr/lib/arkhe/arkhd"

static volatile pid_t supervisor_pid = 0;
static volatile sig_atomic_t shutdown_requested = 0;

static void forward_signal(int sig) {
    if (supervisor_pid > 0) {
        kill(supervisor_pid, sig);
    }
    if (sig == SIGTERM || sig == SIGINT) {
        shutdown_requested = 1;
    }
}

static void reap_zombies(void) {
    int status;
    pid_t pid;
    while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
        if (pid == supervisor_pid) {
            /* Supervisor exited. If shutdown was requested, proceed.
             * Otherwise, restart it. */
            if (shutdown_requested) {
                supervisor_pid = 0;
            } else {
                /* TODO: restart supervisor */
                supervisor_pid = 0;
            }
        }
        /* All other children: just reap. That's our job. */
    }
}

static pid_t spawn_supervisor(void) {
    pid_t pid = fork();
    if (pid < 0) {
        /* Fork failed. Not much we can do. */
        return -1;
    }
    if (pid == 0) {
        /* Child: exec the supervisor */
        char *argv[] = { "arkhd", NULL };
        char *envp[] = { "PATH=/usr/bin:/usr/sbin:/bin:/sbin", NULL };
        execve(SUPERVISOR_PATH, argv, envp);
        /* If exec fails, exit. PID 1 will reap us. */
        _exit(127);
    }
    return pid;
}

int main(void) {
    /* Verify we are PID 1 */
    if (getpid() != 1) {
        fprintf(stderr, "arkhe: pid1 must be run as PID 1\n");
        return 1;
    }

    /* Set up signal handlers: forward to supervisor */
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = forward_signal;
    sa.sa_flags = SA_RESTART;

    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGHUP, &sa, NULL);

    /* Ignore SIGCHLD to avoid signal queuing issues.
     * We reap explicitly via waitpid. */
    struct sigaction sa_chld;
    memset(&sa_chld, 0, sizeof(sa_chld));
    sa_chld.sa_handler = SIG_DFL;
    sigaction(SIGCHLD, &sa_chld, NULL);

    /* Spawn the supervisor */
    supervisor_pid = spawn_supervisor();
    if (supervisor_pid < 0) {
        fprintf(stderr, "arkhe: failed to spawn supervisor\n");
        return 1;
    }

    /* Main loop: reap zombies, wait for shutdown */
    while (!shutdown_requested || supervisor_pid > 0) {
        /* Wait for any signal or child exit */
        pause();
        reap_zombies();
    }

    /* Supervisor has exited and shutdown was requested. Power off. */
    sync();
    reboot(LINUX_REBOOT_CMD_POWER_OFF);

    /* Should never reach here */
    return 0;
}
