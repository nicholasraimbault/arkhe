//! ring module — see docs/ for design
