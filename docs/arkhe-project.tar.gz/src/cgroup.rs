//! cgroup module — see docs/ for design
