//! sandbox module — see docs/ for design
