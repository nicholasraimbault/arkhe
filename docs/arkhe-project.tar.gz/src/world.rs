//! World — the ECS data store
//!
//! All service state lives here as parallel arrays indexed by ServiceId.
//! Systems receive `&mut World` and operate on specific component combinations.
//! No global state. No singletons. One World per supervisor instance.

use std::collections::HashMap;
use std::os::fd::RawFd;

use crate::components::*;

/// Entity identifier. Index into parallel arrays in World.
pub type ServiceId = usize;

/// All service state. Parallel arrays indexed by ServiceId.
pub struct World {
    // === Identity ===
    pub names: Vec<String>,

    // === Static config (loaded from /etc/sv/ at boot, immutable at runtime) ===
    pub run_configs: Vec<RunConfig>,
    pub sandbox_configs: Vec<SandboxConfig>,  // always present, defaults to strict
    pub dependencies: Vec<Option<Dependencies>>,
    pub resource_limits: Vec<Option<ResourceLimits>>,
    pub listen_sockets: Vec<Option<ListenSockets>>,
    pub log_configs: Vec<LogConfig>,  // always present, defaults to 1MB x 10

    // === Runtime state (mutable, changes during operation) ===
    pub states: Vec<RuntimeState>,
    pub readiness: Vec<ReadinessState>,
    pub cgroup_handles: Vec<Option<CgroupHandle>>,

    // === Reverse lookup maps (fd → ServiceId) ===
    pub pidfd_map: HashMap<RawFd, ServiceId>,
    pub socket_map: HashMap<RawFd, ServiceId>,
    pub psi_map: HashMap<RawFd, ServiceId>,
}

impl World {
    pub fn new() -> Self {
        World {
            names: Vec::new(),
            run_configs: Vec::new(),
            sandbox_configs: Vec::new(),
            dependencies: Vec::new(),
            resource_limits: Vec::new(),
            listen_sockets: Vec::new(),
            log_configs: Vec::new(),
            states: Vec::new(),
            readiness: Vec::new(),
            cgroup_handles: Vec::new(),
            pidfd_map: HashMap::new(),
            socket_map: HashMap::new(),
            psi_map: HashMap::new(),
        }
    }

    /// Add a new service to the world. Returns its ServiceId.
    pub fn add_service(&mut self, name: String, run_config: RunConfig) -> ServiceId {
        let id = self.names.len();
        self.names.push(name);
        self.run_configs.push(run_config);
        self.sandbox_configs.push(SandboxConfig::strict_default());
        self.dependencies.push(None);
        self.resource_limits.push(None);
        self.listen_sockets.push(None);
        self.log_configs.push(LogConfig::default());
        self.states.push(RuntimeState::NotStarted);
        self.readiness.push(ReadinessState::default());
        self.cgroup_handles.push(None);
        id
    }

    /// Number of services in the world.
    pub fn len(&self) -> usize {
        self.names.len()
    }

    /// Find service by name. Linear scan — fine for <200 services.
    pub fn find_by_name(&self, name: &str) -> Option<ServiceId> {
        self.names.iter().position(|n| n == name)
    }
}
