//! arkhd — the arkhe supervisor
//!
//! Architecture: ECS (Entity-Component-System) pattern.
//! - World struct holds all service state as parallel arrays
//! - Systems are plain functions dispatched from the io_uring event loop
//! - The io_uring ring IS the ECS scheduler
//!
//! See docs/ARCHITECTURE.md for the full design.

mod world;
mod components;
mod ring;
mod sandbox;
mod cgroup;
mod config;

mod systems {
    pub mod spawn;
    pub mod supervise;
    pub mod deps;
    pub mod log;
    pub mod socket;
    pub mod pressure;
    pub mod status;
}

use world::World;

fn main() {
    // Startup sequence:
    // 1. Set up signal mask (block SIGCHLD, SIGTERM, SIGHUP — handle via signalfd)
    // 2. Create signalfd
    // 3. Create io_uring ring
    // 4. Create /run/arkhe/ and /run/ready/ directories
    // 5. Scan /etc/sv/ → populate World with components (config::load_all)
    // 6. Create cgroups for all services (cgroup::setup_all)
    // 7. Set up inotify watch on /run/ready/
    // 8. Submit initial io_uring ops: signalfd poll, inotify poll
    // 9. Run SpawnSystem for services with no unmet dependencies
    // 10. Enter event loop (see dispatch below)

    eprintln!("arkhd: starting");

    let mut _world = World::new();
    // TODO: config::load_all(&mut world, "/etc/sv");

    // Event loop structure:
    //
    // loop {
    //     ring.submit_and_wait(1);
    //     for cqe in ring.completion() {
    //         match decode_tag(cqe.user_data()) {
    //             Tag::Pidfd(id)   => systems::supervise::on_exit(&mut world, id, &mut ring),
    //             Tag::Inotify     => systems::deps::on_ready(&mut world, &cqe, &mut ring),
    //             Tag::Signal      => systems::signal::on_signal(&mut world, &cqe, &mut ring),
    //             Tag::Splice(id)  => systems::log::on_splice(&mut world, id, &mut ring),
    //             Tag::Accept(id)  => systems::socket::on_accept(&mut world, id, &mut ring),
    //             Tag::Psi(id)     => systems::pressure::on_pressure(&mut world, id, &mut ring),
    //         }
    //     }
    // }

    eprintln!("arkhd: not yet implemented");
    std::process::exit(1);
}
