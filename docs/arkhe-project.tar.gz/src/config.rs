//! config module — see docs/ for design
