//! CLI command implementations
//!
//! Each function reads plain text files from /run/arkhe/ and /etc/sv/.
//! No IPC. No protocols. Just files.

use std::io;

const ARKHE_RUN_DIR: &str = "/run/arkhe";
const SERVICE_DIR: &str = "/etc/sv";
const LOG_DIR: &str = "/var/log/sv";
const READY_DIR: &str = "/run/ready";

pub fn status(_args: &[String]) -> Result<(), io::Error> {
    // TODO: Read /run/arkhe/services/* and format output
    // See docs/CLI.md for output format
    eprintln!("ark status: not yet implemented");
    Ok(())
}

pub fn start(_args: &[String]) -> Result<(), io::Error> {
    // TODO: Signal supervisor to start a service
    eprintln!("ark start: not yet implemented");
    Ok(())
}

pub fn stop(_args: &[String]) -> Result<(), io::Error> {
    // TODO: Signal supervisor to stop a service
    eprintln!("ark stop: not yet implemented");
    Ok(())
}

pub fn restart(args: &[String]) -> Result<(), io::Error> {
    stop(args)?;
    start(args)
}

pub fn log(_args: &[String]) -> Result<(), io::Error> {
    // TODO: Tail /var/log/sv/<service>/current
    // This is a thin wrapper around reading a plain text file
    eprintln!("ark log: not yet implemented");
    Ok(())
}

pub fn check(_args: &[String]) -> Result<(), io::Error> {
    // TODO: Audit all services
    // - List permissive sandboxes
    // - List failing services with plain-language diagnostics
    // - Check for dependency cycles
    // - Report resource pressure
    // - Report boot time
    // See docs/CLI.md for output format
    eprintln!("ark check: not yet implemented");
    Ok(())
}

pub fn new_service(_args: &[String]) -> Result<(), io::Error> {
    // TODO: Create /etc/sv/<n>/ with scaffold files
    // See docs/SERVICE-FORMAT.md for directory structure
    eprintln!("ark new: not yet implemented");
    Ok(())
}

pub fn enable(_args: &[String]) -> Result<(), io::Error> {
    // TODO: Mark service for boot start
    eprintln!("ark enable: not yet implemented");
    Ok(())
}

pub fn disable(_args: &[String]) -> Result<(), io::Error> {
    // TODO: Unmark service from boot start
    eprintln!("ark disable: not yet implemented");
    Ok(())
}
